package com.tema1.main;

public enum GoodsType { Legal, Illegal }
